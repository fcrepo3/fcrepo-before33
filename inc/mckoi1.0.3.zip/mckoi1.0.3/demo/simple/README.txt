
To run this demonstration
-------------------------

To run the demonstation application, type the following at the
prompt;

Windows: java -cp ../../mckoidb.jar;. SimpleApplicationDemo
Unix:    java -cp ../../mckoidb.jar:. SimpleApplicationDemo

If you would like to create the demonstration database, then
remove the 'data' directory and enter;

Windows: java -cp ../../mckoidb.jar;. SimpleDatabaseCreateDemo
Unix:    java -cp ../../mckoidb.jar:. SimpleDatabaseCreateDemo

