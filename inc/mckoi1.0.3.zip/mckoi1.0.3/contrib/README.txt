This directory contains contributions to the project from various developers.

installService.bat uninstallService.bat by
                                 Patrick Godeau <pgodeau@sapex-profor.com>
--------------------------------------------------------------------------
Use to install Mckoi server as an NT service.  Requires the JavaService
package from Alexandria software consulting:
  http://www.alexandriasc.com/software/JavaService/


JDBCQueryTool.java by
           Mike Calder-Smith <mike@gmot.demon.co.uk> and Christophe NIGAUD
--------------------------------------------------------------------------
An improved JDBCQueryTool featuring a database schema tree, command recall, and
a table inspection interface.  To use copy JDBCQueryTool.java into the
com.mckoi.tools package in the source and compile.


mckoicon.ico, mckicon2.ico by
            Michael Desorcie <m.desorcie@neopostinc.com> and Tobias Downer
--------------------------------------------------------------------------
Windows icons you can use for applications with Mckoi SQL Database.


mckoi-service.xml by Howard Lewis Ship
--------------------------------------
JBoss Mckoi MBean service.