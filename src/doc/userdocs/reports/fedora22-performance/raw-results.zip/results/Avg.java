import java.io.*;

public class Avg {

    public static void main(String[] args) throws Exception {

        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(new File(args[0]))));

        int num = 0;
        long total = 0L;

        String line = reader.readLine();
        while (line != null) {
            String[] parts = line.trim().split(" ");
            if (parts.length == 2) {
                num++;
                total += Long.parseLong(parts[1]);
            }
            line = reader.readLine();
        }

        reader.close();

        double avg = (double) total / (double) num;

        System.out.println(avg);

    }

}
