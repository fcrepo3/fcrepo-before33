package fedora211vs22.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import java.util.Iterator;

public class Test {

    private FedoraAdaptor _adaptor;

    public Test(FedoraAdaptor adaptor) {
        _adaptor = adaptor;
    }

    /**
     * To prepare for tests, this ingests all files in the given directory.
     */
    public void setUp(File dir)
            throws Exception {
        System.out.print("Ingesting object(s) in directory: " + dir.getPath()
                + " ");
        File[] files = dir.listFiles();
        for (int i = 0; i < files.length; i++) {
            System.out.print(".");
            _adaptor.ingestObject(getString(files[i]));
        }
        System.out.println("[INGESTED " + files.length + "]");
    }

    private String getString(File file)
            throws Exception {
        StringBuffer s = new StringBuffer();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(file)));
        try {
            String line = reader.readLine();
            while (line != null) {
                s.append(line + "\n");
                line = reader.readLine();
            }
            return s.toString();
        } finally {
            reader.close();
        }
    }

    /**
     * To clean up after testing, this purges all objects in the repository.
     */
    public void tearDown()
            throws Exception {
        System.out.print("Purging all data objects ");
        purgeAll(_adaptor.listDataObjects());
        System.out.print("Purging all BMech objects ");
        purgeAll(_adaptor.listBMechObjects());
        System.out.print("Purging all BDef objects ");
        purgeAll(_adaptor.listBDefObjects());
    }

    private void purgeAll(Iterator<String> pids)
            throws Exception {
        int i = 0;
        while (pids.hasNext()) {
            System.out.print(".");
            _adaptor.purgeObject(pids.next());
            i++;
        }
        System.out.println("[PURGED " + i + "]");
    }

    private String getFOXML(int objNum, boolean managedInline)
            throws Exception {
        String pid = "demo:obj" + objNum;
        int nextObjNum = objNum + 1;
        String nextPid = "demo:obj" + nextObjNum;
        StringBuffer out = new StringBuffer();
        out.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        out.append("<foxml:digitalObject PID=\"" + pid + "\"");
        out.append("    xmlns:foxml=\"info:fedora/fedora-system:def/foxml#\">");
        out.append("  <foxml:objectProperties>");
        out.append("    <foxml:property NAME=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#type\" VALUE=\"FedoraObject\"/>");
        out.append("    <foxml:property NAME=\"info:fedora/fedora-system:def/model#state\" VALUE=\"Active\"/>");
        out.append("    <foxml:property NAME=\"info:fedora/fedora-system:def/model#label\" VALUE=\"Test Object " + objNum + "\"/>");
        out.append("  </foxml:objectProperties>");
        out.append("  <foxml:datastream CONTROL_GROUP=\"X\" ID=\"DC\" STATE=\"A\" VERSIONABLE=\"true\">");
        out.append("    <foxml:datastreamVersion ID=\"DC1.0\" LABEL=\"label\" MIMETYPE=\"text/xml\">");
        out.append("      <foxml:xmlContent>");
        out.append("        <oai_dc:dc xmlns:dc=\"http://purl.org/dc/elements/1.1/\"");
        out.append("            xmlns:oai_dc=\"http://www.openarchives.org/OAI/2.0/oai_dc/\">");
        out.append("          <dc:title>Test Object " + objNum + "</dc:title>");
        out.append("          <dc:description>This is demo:obj1</dc:description>");
        out.append("          <dc:identifier>" + pid + "</dc:identifier>");
        out.append("        </oai_dc:dc>");
        out.append("      </foxml:xmlContent>");
        out.append("    </foxml:datastreamVersion>");
        out.append("  </foxml:datastream>");
        out.append("  <foxml:datastream CONTROL_GROUP=\"X\" ID=\"RELS-EXT\" STATE=\"A\" VERSIONABLE=\"true\">");
        out.append("    <foxml:datastreamVersion ID=\"RELS-EXT.0\" LABEL=\"label\" MIMETYPE=\"text/xml\">");
        out.append("      <foxml:xmlContent>");
        out.append("        <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\"");
        out.append("            xmlns:example=\"http://example.org/\">");
        out.append("          <rdf:Description rdf:about=\"info:fedora/" + pid + "\">");
        out.append("            <example:someProperty>some value</example:someProperty>");
        out.append("            <example:nextObject rdf:resource=\"info:fedora/" + nextPid + "\"/>");
        out.append("          </rdf:Description>");
        out.append("        </rdf:RDF>");
        out.append("      </foxml:xmlContent>");
        out.append("    </foxml:datastreamVersion>");
        out.append("  </foxml:datastream>");
        out.append("  <foxml:datastream CONTROL_GROUP=\"M\" ID=\"M1\" STATE=\"A\" VERSIONABLE=\"true\">");
        out.append("    <foxml:datastreamVersion ID=\"M1.0\" LABEL=\"label\" MIMETYPE=\"text/xml\">");
        if (managedInline) {
            out.append("      <foxml:binaryContent> ");
            out.append("        PGV4YW1wbGU+ZXhhbXBsZTwvZXhhbXBsZT4=");
            out.append("      </foxml:binaryContent>");
        } else {
            String ref = _adaptor.upload("<example>example</example>");
            out.append("      <foxml:contentLocation REF=\"" + ref + "\" TYPE=\"URL\"/>");
        }
        out.append("    </foxml:datastreamVersion>");
        out.append("  </foxml:datastream>");
        out.append("  <foxml:datastream CONTROL_GROUP=\"M\" ID=\"M2\" STATE=\"A\" VERSIONABLE=\"false\">");
        out.append("    <foxml:datastreamVersion ID=\"M2.0\" LABEL=\"label\" MIMETYPE=\"text/xml\">");
        if (managedInline) {
            out.append("      <foxml:binaryContent>");
            out.append("        PGV4YW1wbGU+ZXhhbXBsZTwvZXhhbXBsZT4=");
            out.append("      </foxml:binaryContent>");
        } else {
            String ref = _adaptor.upload("<example>example</example>");
            out.append("      <foxml:contentLocation REF=\"" + ref + "\" TYPE=\"URL\"/>");
        }
        out.append("    </foxml:datastreamVersion>");
        out.append("  </foxml:datastream>");
        out.append("  <foxml:datastream CONTROL_GROUP=\"X\" ID=\"X1\" STATE=\"A\" VERSIONABLE=\"true\">");
        out.append("    <foxml:datastreamVersion ID=\"X1.0\" LABEL=\"label\" MIMETYPE=\"text/xml\">");
        out.append("      <foxml:xmlContent>");
        out.append("        <example>example</example>");
        out.append("      </foxml:xmlContent>");
        out.append("    </foxml:datastreamVersion>");
        out.append("  </foxml:datastream>");
        out.append("  <foxml:datastream CONTROL_GROUP=\"X\" ID=\"X2\" STATE=\"A\" VERSIONABLE=\"false\">");
        out.append("    <foxml:datastreamVersion ID=\"X2.0\" LABEL=\"label\" MIMETYPE=\"text/xml\">");
        out.append("      <foxml:xmlContent>");
        out.append("        <example>example</example>");
        out.append("      </foxml:xmlContent>");
        out.append("    </foxml:datastreamVersion>");
        out.append("  </foxml:datastream>");
        out.append("</foxml:digitalObject>");
        return out.toString();
    }

    public void ingestObj(boolean managedInline, int numObjects, PrintWriter out)
            throws Exception {
        System.out.print("Ingesting " + numObjects + " objects ");
        for (int objNum = 1; objNum <= numObjects; objNum++) {
            String foxml = getFOXML(objNum, managedInline);
            long startTime = System.currentTimeMillis();
            _adaptor.ingestObject(foxml);
            long duration = System.currentTimeMillis() - startTime;
            out.println(objNum + " " + duration);
            System.out.print(".");
        }
        System.out.println("DONE");
    }

    public void modDSByRef(boolean versionable, int numObjects, PrintWriter out)
            throws Exception {
        String kind;
        String dsId;
        if (versionable) {
            kind = "versionable, managed";
            dsId = "M1";
        } else {
            kind = "non-versionable, managed";
            dsId = "M2";
        }
        String content = "<example>example</example>";
        System.out.print("Modifying " + kind + " datastreams for "
                + numObjects + " objects ");
        for (int objNum = 1; objNum <= numObjects; objNum++) {
            long startTime = System.currentTimeMillis();
            _adaptor.modifyDatastreamByReference("demo:obj" + objNum, dsId, content);
            long duration = System.currentTimeMillis() - startTime;
            out.println(objNum + " " + duration);
            System.out.print(".");
        }
        System.out.println("DONE");
    }

    public void modDSByVal(boolean versionable, int numObjects, PrintWriter out)
            throws Exception {
        String kind;
        String dsId;
        if (versionable) {
            kind = "versionable, inline xml";
            dsId = "X1";
        } else {
            kind = "non-versionable, inline xml";
            dsId = "X2";
        }
        String content = "<example>example</example>";
        System.out.print("Modifying " + kind + " datastreams for "
                + numObjects + " objects ");
        for (int objNum = 1; objNum <= numObjects; objNum++) {
            long startTime = System.currentTimeMillis();
            _adaptor.modifyDatastreamByValue("demo:obj" + objNum, dsId, content);
            long duration = System.currentTimeMillis() - startTime;
            out.println(objNum + " " + duration);
            System.out.print(".");
        }
        System.out.println("DONE");
    }

    public void purgeDS(boolean managed, boolean versionable, int numObjects, PrintWriter out)
            throws Exception {
        String kind;
        String dsId;
        if (managed) {
            if (versionable) {
                kind = "versionable, managed";
                dsId = "M1";
            } else {
                kind = "non-versionable, managed";
                dsId = "M2";
            }
        } else {
            if (versionable) {
                kind = "versionable, inline xml";
                dsId = "X1";
            } else {
                kind = "non-versionable, inline xml";
                dsId = "X2";
            }
        }
        System.out.print("Purging " + kind + " datastreams for "
                + numObjects + " objects ");
        for (int objNum = 1; objNum <= numObjects; objNum++) {
            long startTime = System.currentTimeMillis();
            _adaptor.purgeDatastream("demo:obj" + objNum, dsId);
            long duration = System.currentTimeMillis() - startTime;
            out.println(objNum + " " + duration);
            System.out.print(".");
        }
        System.out.println("DONE");
    }

    public void purgeObj(int numObjects, PrintWriter out)
            throws Exception {
        System.out.print("Purging " + numObjects + " objects ");
        for (int objNum = 1; objNum <= numObjects; objNum++) {
            long startTime = System.currentTimeMillis();
            _adaptor.purgeObject("demo:obj" + objNum);
            long duration = System.currentTimeMillis() - startTime;
            out.println(objNum + " " + duration);
            System.out.print(".");
        }   
        System.out.println("DONE");
    }

    /**
     * The following system properties are required:
     * 
     * version       = 2.1.1 | 2.2
     * baseURL       = http://localhost:8080/fedora
     * username      = fedoraAdmin
     * password      = fedoraAdmin
     * command       = test | setUp | tearDown
     *
     * If command is "setUp", the following is also required:
     *
     * dir           = /path/to/dir/of/objects
     *
     * If command is "test", the following are also required:
     *
     * testType      = ingestObj | modDSByRef | modDSByVal | purgeDS | purgeObj
     * numObjects    = 1000
     * outputFile    = filename.dat
     *
     * If testType is "ingestObj", the following is also required:
     *
     * managedInline = true | false
     *
     * If testType is "modDSByRef" or "modDSByVal", the following is also required:
     *
     * versionable   = true | false
     *
     * If testType is "purgeDS", the following are also required:
     *
     * managed       = true | false
     * versionable   = true | false
     */
    public static void main(String[] args)
            throws Exception {

        // Tell commons-logging to use log4j
        final String pfx = "org.apache.commons.logging.";
        if (System.getProperty(pfx + "LogFactory") == null) {
            System.setProperty(pfx + "LogFactory", pfx + "impl.Log4jFactory");
            System.setProperty(pfx + "Log", pfx + "impl.Log4JLogger");
        }

        String version = getString("version");
        String baseURL = getString("baseURL");
        String username = getString("username");
        String password = getString("password");
        String command = getString("command");

        String adaptorClassName;
        if (version.equals("2.1.1")) {
            adaptorClassName = "fedora211vs22.fedora211.Fedora211Adaptor";
        } else if (version.equals("2.2")) {
            adaptorClassName = "fedora211vs22.fedora22.Fedora22Adaptor";
        } else {
            throw new Exception("Unrecognized version: " + version);
        }

        FedoraAdaptor adaptor = (FedoraAdaptor) 
                Class.forName(adaptorClassName).newInstance();
        adaptor.init(baseURL, username, password);

        Test test = new Test(adaptor);

        if (command.equals("test")) {

            String testType = getString("testType");
            int numObjects = getInt("numObjects");
            String outputFile = getString("outputFile");

            PrintWriter out = new PrintWriter(new FileOutputStream(
                    new File(outputFile)));

            try {
                if (testType.equals("ingestObj")) {
                    test.ingestObj(getBoolean("managedInline"), numObjects, out);
                } else if (testType.equals("modDSByRef")) {
                    test.modDSByRef(getBoolean("versionable"), numObjects, out);
                } else if (testType.equals("modDSByVal")) {
                    test.modDSByVal(getBoolean("versionable"), numObjects, out);
                } else if (testType.equals("purgeDS")) {
                    test.purgeDS(getBoolean("managed"), getBoolean("versionable"), numObjects, out);
                } else if (testType.equals("purgeObj")) {
                    test.purgeObj(numObjects, out);
                } else {
                    throw new Exception("Unrecognized testType: " + testType);
                }
            } finally {
                out.flush();
                out.close();
            }
            
        } else if (command.equals("setUp")) {
            String dir = getString("dir");
            test.setUp(new File(dir));
        } else if (command.equals("tearDown")) {
            test.tearDown();
        } else {
            throw new Exception("Unrecognized command: " + command);
        }

    }

    private static int getInt(String name)
            throws Exception {
        return Integer.parseInt(getString(name));
    }

    private static boolean getBoolean(String name)
            throws Exception {
        String value = getString(name);
        if (value.equals("true")) {
            return true;
        } else if (value.equals("false")) {
            return false;
        } else {
            throw new Exception("Must specify true or false for value: " + name);
        }
    }

    private static String getString(String name)
            throws Exception {
        String value = System.getProperty(name);
        if (value == null) {
            throw new Exception("Required system property is not set: " + name);
        } else {
            return value;
        }
    }

}
