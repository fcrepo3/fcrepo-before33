package fedora211vs22.fedora22;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;

import java.net.URL;

import java.util.Iterator;

import fedora.client.FedoraClient;
import fedora.client.Uploader;

import fedora.server.access.FedoraAPIA;
import fedora.server.management.FedoraAPIM;
import fedora.server.types.gen.Condition;
import fedora.server.types.gen.ComparisonOperator;
import fedora.server.types.gen.FieldSearchQuery;
import fedora.server.types.gen.FieldSearchResult;
import fedora.server.types.gen.ObjectFields;

import org.apache.axis.types.NonNegativeInteger;

import fedora211vs22.common.FedoraAdaptor;
import fedora211vs22.common.PIDFileIterator;

public class Fedora22Adaptor
        implements FedoraAdaptor {

    private FedoraClient _fedora;

    private FedoraAPIA _apia;

    private FedoraAPIM _apim;

    public Fedora22Adaptor() {
    }

    public void init(String baseURL, String user, String pass)
            throws Exception {
        // initialize fedora client, apia and apim interfaces
        _fedora = new FedoraClient(baseURL, user, pass);
        _apia = _fedora.getAPIA();
        _apim = _fedora.getAPIM();
    }

    public void ingestObject(final String foxml)
            throws Exception {
        _apim.ingest(foxml.getBytes("UTF-8"), "foxml1.0", "");
    }

    public void modifyDatastreamByReference(final String pid,
            final String dsId, final String content)
            throws Exception {
        String reference = upload(content);
        _apim.modifyDatastreamByReference(pid, dsId, new String[0], null,
                null, null, reference, null, null, "", false); 
    }

    public String upload(final String content)
            throws Exception {
        File file = File.createTempFile("fedora211vs22-upload", ".txt");
        PrintWriter out = null;
        try {
            out = new PrintWriter(new FileOutputStream(file));
            out.print(content);
            out.flush();
            out.close();
            return _fedora.uploadFile(file);
        } finally {
            if (out != null) {
                try { out.close(); } catch (Exception e) { }
            }
            file.delete();
        }
    }

    public void modifyDatastreamByValue(final String pid, final String dsId,
            final String content)
            throws Exception {
        _apim.modifyDatastreamByValue(pid, dsId, new String[0], null, null,
                null, content.getBytes("UTF-8"), null, null, "", false);
    }

    public void purgeDatastream(final String pid, final String dsId)
            throws Exception {
        _apim.purgeDatastream(pid, dsId, null, null, "", false);
    }

    public void purgeObject(final String pid)
            throws Exception {
        _apim.purgeObject(pid, "", false);
    }

    public Iterator<String> listBDefObjects()
            throws Exception {
        File pidFile = dumpPIDs("D");
        return new PIDFileIterator(pidFile, true);
    }

    public Iterator<String> listBMechObjects()
            throws Exception {
        File pidFile = dumpPIDs("M");
        return new PIDFileIterator(pidFile, true);
    }

    public Iterator<String> listDataObjects()
            throws Exception {
        File pidFile = dumpPIDs("O");
        return new PIDFileIterator(pidFile, true);
    }

    private File dumpPIDs(final String fType)
            throws Exception {
        boolean successful = false;
        File file = File.createTempFile("fedora211vs22-pids", ".txt");
        PrintWriter out = null;
        try {
            out = new PrintWriter(new FileOutputStream(file));
            dumpPIDs(fType, out);
            out.flush();
            out.close();
            successful = true;
            return file;
        } finally {
            if (!successful) {
                if (out != null) {
                    try { out.close(); } catch (Exception e) { }
                }
                file.delete();
            }
        }
    }

    private void dumpPIDs(final String fType, final PrintWriter out)
            throws Exception {
        // prepare the query
        FieldSearchQuery query = new FieldSearchQuery();
        Condition fTypeCondition = new Condition();
        fTypeCondition.setProperty("fType");
        fTypeCondition.setOperator(ComparisonOperator.eq);
        fTypeCondition.setValue(fType);
        query.setConditions(new Condition[] {fTypeCondition});
        // start the query
        FieldSearchResult result = _apia.findObjects(new String[] {"pid"},
                new NonNegativeInteger("1000"), query);
        // dump till no more result chunks
        while (result != null) {
            result = dumpPIDs(result, out);
        }
    }

    private FieldSearchResult dumpPIDs(final FieldSearchResult result,
            final PrintWriter out)
            throws Exception {
        // send all the pids in this chunk to the printwriter
        ObjectFields[] fields = result.getResultList();
        for (int i = 0; i < fields.length; i++) {
            out.println(fields[i].getPid());
        }
        // return the next chunk of results, or null if exhausted
        String sessionToken = null;
        if (result.getListSession() != null) {
            sessionToken = result.getListSession().getToken();
        }
        if (sessionToken != null) {
            return _apia.resumeFindObjects(sessionToken);
        } else {
            return null;
        }
    }

}
