package fedora211vs22.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import java.util.Iterator;

public class PIDFileIterator implements Iterator<String> {

    private File _file;

    private boolean _autoDelete;

    private String _nextPID;

    private BufferedReader _reader;

    public PIDFileIterator(File file, boolean autoDelete)
            throws Exception {
        _file = file;
        _autoDelete = autoDelete;
        try {
            _reader = new BufferedReader(new InputStreamReader(new FileInputStream(_file)));
            setNextPID();
        } catch (Exception e) {
            try { _reader.close(); } catch (Exception e2) { }
            finalize();
            throw e;
        }
    }

    private void setNextPID() {
        if (_reader != null) {
            try {
                String pid = "";
                while (pid != null && pid.length() == 0) {
                    pid = _reader.readLine();
                }
                _nextPID = pid;
                if (_nextPID == null) {
                    _reader.close();
                    finalize();
                }
            } catch (Exception e) {
                throw new RuntimeException("error getting next pid", e);
            }
        }
    }

    public boolean hasNext() {
        return _nextPID != null;
    }

    public String next() {
        try {
            return _nextPID;
        } finally {
            setNextPID();
        }
    }

    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException("not supported");
    }

    public void finalize() {
        if (_autoDelete) {
            _file.delete();
        }
    }

}
