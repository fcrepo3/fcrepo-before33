package fedora211vs22.common;

import java.util.Iterator;

public interface FedoraAdaptor {

    void init(String baseURL, String user, String pass)
            throws Exception;

    String upload(String content)
            throws Exception;

    void ingestObject(String foxml)
            throws Exception;

    void modifyDatastreamByReference(String pid, String dsId, String content)
            throws Exception;

    void modifyDatastreamByValue(String pid, String dsId, String content)
            throws Exception;

    void purgeDatastream(String pid, String dsId)
            throws Exception;

    void purgeObject(String pid)
            throws Exception;

    Iterator<String> listBDefObjects()
            throws Exception;

    Iterator<String> listBMechObjects()
            throws Exception;

    Iterator<String> listDataObjects()
            throws Exception;

}
