package fedora211vs22.fedora211;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.MultiThreadedHttpConnectionManager;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.MultipartPostMethod;

import fedora.client.FedoraClient;

public class Uploader {

    private MultiThreadedHttpConnectionManager m_cManager=
            new MultiThreadedHttpConnectionManager();

    private String m_uploadURL;
    private UsernamePasswordCredentials m_creds;
    private FedoraClient fc;

    /**
     * Construct an uploader to a certain repository as a certain user.
     */
    public Uploader(String protocol, String host, int port, String user, String pass)
            throws IOException 
    {
        m_uploadURL = protocol + "://" + host + ":" + port + "/fedora/management/upload";
        m_creds = new UsernamePasswordCredentials(user, pass);
        String baseURL = protocol + "://" + host + ":" + port + "/fedora";
        fc = new FedoraClient(baseURL, user, pass);        
    }

    /**
     * Send a file to the server, getting back the identifier.
     */
    public String upload(File in) throws IOException {
        MultipartPostMethod post=null;
        
        try {
            HttpClient client = fc.getHttpClient();
            post=new MultipartPostMethod(m_uploadURL);
            post.setDoAuthentication(true);
            post.addParameter("file", in);
            int resultCode=client.executeMethod(post);
            if (resultCode!=201) {
                throw new IOException(HttpStatus.getStatusText(resultCode)
                        + ": " 
                        + replaceNewlines(post.getResponseBodyAsString(), " "));
            }
            return replaceNewlines(post.getResponseBodyAsString(), "");
        } catch (Exception e) {
            throw new IOException(e.getMessage());
        } finally {
            if (post!=null) post.releaseConnection();
        }

    }

    /**
     * Replace newlines with the given string.
     */
    private static String replaceNewlines(String in, String replaceWith) {
        return in.replaceAll("\r", replaceWith).replaceAll("\n", replaceWith);
    }

}
